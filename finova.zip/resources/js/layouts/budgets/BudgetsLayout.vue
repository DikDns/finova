<script setup lang="ts">
import BudgetsSidebarLayout from '@/layouts/budgets/BudgetsSidebarLayout.vue';
</script>

<template>
    <BudgetsSidebarLayout>
        <slot />
    </BudgetsSidebarLayout>
</template>
