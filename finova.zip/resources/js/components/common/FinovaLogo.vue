<script setup lang="ts">
import FinovaLogoIcon from '@/components/common/FinovaLogoIcon.vue';
</script>

<template>
    <div class="text-sidebar-primary-foreground flex aspect-square size-8 items-center justify-center rounded-md">
        <FinovaLogoIcon class="size-5 fill-current text-white" />
    </div>
    <div class="ml-1 grid flex-1 text-left text-sm">
        <span class="mb-0.5 truncate font-serif leading-none font-semibold">Finova</span>
        <span class="text-muted-foreground truncate text-xs">Financial Innovation</span>
    </div>
</template>
