<script setup lang="ts">
interface Props {
    budget_id?: number;
}

defineProps<Props>();
</script>
